/* ==========================================
   TEEN PATTI LIVE - Frontend Client
   ========================================== */

'use strict';

// ===== STATE =====
const State = {
  socket: null,
  roomId: null,
  playerId: null,
  playerName: null,
  isHost: false,
  gameState: null,
  myHand: [],
  cardsRevealed: false,
  currentRound: null,
  players: {},
};

// ===== SOCKET INIT =====
function initSocket() {
  State.socket = io(window.location.origin, {
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 2000,
  });

  State.socket.on('connect', () => {
    console.log('Connected:', State.socket.id);
    // Auto-rejoin if we have state
    if (State.roomId && State.playerId) {
      Game.rejoin();
    }
  });

  State.socket.on('disconnect', () => {
    UI.toast('Connection lost. Reconnecting...', 'error');
  });

  State.socket.on('reconnect', () => {
    UI.toast('Reconnected!', 'success');
  });

  State.socket.on('player_joined', (data) => {
    State.gameState = data.state;
    UI.updateLobby(data.state);
    UI.toast(`${data.playerName} joined!`, 'info');
  });

  State.socket.on('round_started', (data) => {
    State.gameState = data.state;
    State.myHand = data.hand || [];
    State.cardsRevealed = false;
    State.currentRound = data.state.round;

    UI.hideOverlay();
    UI.showScreen('game');
    UI.renderGame(data.state);
    UI.renderMyCards();
    UI.updateActionArea(data.state);
    UI.updateVariationBadge(data.variation, data.jokers);
    UI.toast(`New round! ${data.variation.name}`, 'gold');
    SFX.play('deal');
  });

  State.socket.on('action_result', (data) => {
    State.gameState = data.state;
    State.currentRound = data.state.round;
    UI.renderGame(data.state);
    UI.updateActionArea(data.state);
    UI.addActionLog(data.message);

    if (data.roundOver) {
      UI.showRoundOver(data);
      SFX.play('win');
    } else {
      SFX.play('chip');
    }

    if (data.sideshowRequest) {
      if (data.sideshowRequest.target === State.playerId) {
        UI.showSideshowRequest(data.playerName);
      }
    }
    if (data.sideshowResult) {
      UI.toast(`${data.sideshowResult.loserName} loses sideshow`, 'info');
    }
  });

  State.socket.on('state_update', (data) => {
    State.gameState = data.state;
    UI.renderGame(data.state);
    UI.updateActionArea(data.state);
  });

  State.socket.on('sideshow_request', (data) => {
    UI.showSideshowRequest(data.requesterName);
  });

  State.socket.on('chat_message', (msg) => {
    UI.appendChatMessage(msg);
  });

  State.socket.on('player_disconnected', (data) => {
    UI.toast(`${data.playerName} disconnected`, 'error');
    State.gameState = data.state;
    UI.renderGame(data.state);
  });

  State.socket.on('game_ended', (data) => {
    State.gameState = data.state;
    State.myHand = [];
    State.cardsRevealed = false;
    UI.showScreen('lobby');
    UI.updateLobby(data.state);
    UI.toast('Game ended by host', 'info');
    UI.hideOverlay();
  });

  State.socket.on('kicked', (data) => {
    UI.toast('You were removed from the room', 'error');
    setTimeout(() => UI.showLanding(), 2000);
  });
}

// ===== GAME ACTIONS =====
const Game = {
  createRoom() {
    const name = document.getElementById('create-name').value.trim();
    if (!name) return UI.toast('Please enter your name', 'error');
    if (name.length < 2) return UI.toast('Name too short', 'error');

    const chips = parseInt(document.getElementById('create-chips').value) || 1000;
    const minBet = parseInt(document.getElementById('create-bet').value) || 10;
    const maxPlayers = parseInt(document.getElementById('create-maxplayers').value) || 6;
    const password = document.getElementById('create-password').value.trim();

    State.playerName = name;
    UI.showLoading('Creating room...');

    State.socket.emit('create_room', {
      playerName: name,
      settings: { startingChips: chips, minBet, maxPlayers, password: password || null }
    }, (res) => {
      UI.hideLoading();
      if (res.error) return UI.toast(res.error, 'error');

      State.roomId = res.roomId;
      State.playerId = res.playerId;
      State.gameState = res.state;
      State.isHost = true;
      Storage.save();

      UI.showScreen('lobby');
      UI.updateLobby(res.state);
    });
  },

  joinRoom(roomId, name, password) {
    const rId = roomId || document.getElementById('join-code').value.trim().toUpperCase();
    const pName = name || document.getElementById('join-name').value.trim();
    const pw = password || document.getElementById('join-password').value.trim();

    if (!pName) return UI.toast('Please enter your name', 'error');
    if (!rId || rId.length < 6) return UI.toast('Please enter a valid room code', 'error');

    State.playerName = pName;
    UI.showLoading('Joining room...');

    State.socket.emit('join_room', {
      roomId: rId, playerName: pName, password: pw || null,
      playerId: State.playerId || null
    }, (res) => {
      UI.hideLoading();
      if (res.error) return UI.toast(res.error, 'error');

      State.roomId = res.roomId;
      State.playerId = res.playerId;
      State.gameState = res.state;
      State.myHand = res.hand || [];
      State.isHost = res.state.players[State.playerId]?.isHost || false;
      Storage.save();

      if (res.state.gameState === 'playing') {
        State.cardsRevealed = State.myHand.length > 0 && !res.state.players[State.playerId]?.isBlind;
        UI.showScreen('game');
        UI.renderGame(res.state);
        UI.renderMyCards();
        UI.updateActionArea(res.state);
      } else {
        UI.showScreen('lobby');
        UI.updateLobby(res.state);
      }
    });
  },

  rejoin() {
    if (!State.roomId || !State.playerId) return;
    State.socket.emit('join_room', {
      roomId: State.roomId, playerName: State.playerName,
      playerId: State.playerId, password: null
    }, (res) => {
      if (res.error) return;
      State.gameState = res.state;
      State.myHand = res.hand || [];
      State.isHost = res.state.players[State.playerId]?.isHost || false;
      if (res.state.gameState === 'playing') {
        UI.renderGame(res.state);
        UI.renderMyCards();
        UI.updateActionArea(res.state);
      } else {
        UI.updateLobby(res.state);
      }
    });
  },

  startGame() {
    State.socket.emit('start_game', {}, (res) => {
      if (res.error) UI.toast(res.error, 'error');
    });
  },

  action(actionType, amount) {
    if (!State.currentRound) return;
    const myTurn = State.currentRound.currentTurn === State.playerId;

    // Sideshow accept/reject can happen without being your turn
    if (actionType !== 'sideshow_accept' && actionType !== 'sideshow_reject') {
      if (!myTurn) return UI.toast("It's not your turn!", 'error');
    }

    State.socket.emit('player_action', { action: actionType, amount: amount || 0 }, (res) => {
      if (res.error) return UI.toast(res.error, 'error');
      if (actionType === 'sideshow_accept' || actionType === 'sideshow_reject') {
        UI.hideSideshowRequest();
      }
      UI.hideRaise();
    });
  },

  raiseAction() {
    const amount = parseInt(document.getElementById('raise-slider').value);
    this.action('raise', amount);
  },

  seeCards() {
    if (State.cardsRevealed) return;
    const myTurn = State.currentRound?.currentTurn === State.playerId;
    if (!myTurn) return UI.toast("You can only see cards on your turn", 'error');

    State.socket.emit('see_cards', {}, (res) => {
      if (res.error) return UI.toast(res.error, 'error');
      State.myHand = res.hand || State.myHand;
      State.cardsRevealed = true;
      UI.renderMyCards();
      // Update game state
      if (State.gameState) {
        if (State.gameState.players[State.playerId]) {
          State.gameState.players[State.playerId].isBlind = false;
        }
      }
      UI.updateActionArea(State.gameState);
      SFX.play('flip');
    });
  },

  sendChat() {
    const input = document.getElementById('chat-input');
    const msg = input.value.trim();
    if (!msg) return;
    State.socket.emit('chat_message', { message: msg });
    input.value = '';
  },

  endGame() {
    if (!State.isHost) return;
    State.socket.emit('end_game', {}, (res) => {
      if (res?.error) UI.toast(res.error, 'error');
    });
  },
};

// ===== UI =====
const UI = {
  showScreen(name) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const s = document.getElementById(`screen-${name}`);
    if (s) s.classList.add('active');
  },

  showLanding() {
    State.roomId = null; State.playerId = null;
    State.isHost = false; State.gameState = null;
    Storage.clear();
    this.showScreen('landing');
  },

  showCreateRoom() { this.showScreen('create'); },
  showJoinRoom() { this.showScreen('join'); },

  showLoading(text = 'Loading...') {
    document.getElementById('loading-text').textContent = text;
    document.getElementById('loading-overlay').style.display = 'flex';
  },
  hideLoading() {
    document.getElementById('loading-overlay').style.display = 'none';
  },

  updateLobby(state) {
    const roomId = state.id;
    const link = `${window.location.origin}/room/${roomId}`;

    document.getElementById('lobby-room-id').textContent = roomId;
    document.getElementById('lobby-link').value = link;
    document.getElementById('share-link-display').textContent = link;

    const settings = state.settings;
    document.getElementById('lobby-settings').innerHTML = `
      <span>💰 ₹${settings.startingChips} chips</span>
      <span>🎯 Boot: ₹${settings.minBet}</span>
      <span>👥 ${Object.keys(state.players).length}/${settings.maxPlayers}</span>
      ${settings.password ? '<span>🔒 Password</span>' : '<span>🔓 Open</span>'}
    `;

    // Players
    const container = document.getElementById('lobby-players');
    container.innerHTML = '';
    for (const [pid, player] of Object.entries(state.players)) {
      const card = document.createElement('div');
      card.className = `lobby-player-card ${player.isHost ? 'host' : ''}`;
      card.innerHTML = `
        <div class="player-avatar-lg" style="background:${player.avatar.color}">
          ${player.avatar.initials}
        </div>
        <div class="lobby-player-info">
          <div class="lobby-player-name">${escHtml(player.name)}</div>
          <div class="lobby-player-badge">${player.isHost ? '👑 Host' : ''} ${!player.isActive ? '🔴 offline' : ''}</div>
        </div>
      `;
      container.appendChild(card);
    }

    // Host controls
    const isHost = state.players[State.playerId]?.isHost;
    const startBtn = document.getElementById('start-game-btn');
    const waitMsg = document.getElementById('lobby-waiting-msg');
    const playerCount = Object.keys(state.players).length;

    if (isHost) {
      startBtn.style.display = playerCount >= 2 ? 'inline-flex' : 'none';
      waitMsg.textContent = playerCount < 2 ? 'Waiting for at least 1 more player...' : 'Ready to start!';
    } else {
      startBtn.style.display = 'none';
      waitMsg.textContent = 'Waiting for host to start...';
    }
  },

  renderGame(state) {
    if (!state) return;
    const myPlayer = state.players[State.playerId];
    const round = state.round;

    // Update pot
    document.getElementById('pot-amount').textContent = `₹${round?.pot || 0}`;
    document.getElementById('game-room-id').textContent = state.id;

    // Host button
    document.getElementById('host-end-btn').style.display = State.isHost ? 'inline-flex' : 'none';

    // My info
    if (myPlayer) {
      const myAvatar = document.getElementById('my-avatar');
      myAvatar.style.background = myPlayer.avatar.color;
      myAvatar.textContent = myPlayer.avatar.initials;
      document.getElementById('my-name').textContent = myPlayer.name;
      document.getElementById('my-chips').textContent = myPlayer.chips;

      const statusEl = document.getElementById('my-status');
      if (myPlayer.isFolded) {
        statusEl.textContent = 'Folded';
        statusEl.className = 'my-status folded-status';
      } else if (myPlayer.isBlind) {
        statusEl.textContent = 'Blind';
        statusEl.className = 'my-status blind-status';
      } else {
        statusEl.textContent = 'Seen';
        statusEl.className = 'my-status seen-status';
      }
    }

    // Turn indicator
    if (round) {
      const turnPlayer = state.players[round.currentTurn];
      const isMy = round.currentTurn === State.playerId;
      document.getElementById('turn-indicator').textContent = isMy ? '⚡ YOUR TURN' : `${turnPlayer?.name || '?'}'s turn`;
    }

    // Opponents
    this.renderOpponents(state);

    // Jokers
    this.renderJokers(state);
  },

  renderOpponents(state) {
    const area = document.getElementById('opponents-area');
    area.innerHTML = '';
    const round = state.round;

    for (const [pid, player] of Object.entries(state.players)) {
      if (pid === State.playerId) continue;
      const isActive = round?.currentTurn === pid;
      const isFolded = player.isFolded;

      const seat = document.createElement('div');
      seat.className = `opponent-seat ${isActive ? 'active-turn' : ''} ${isFolded ? 'folded' : ''}`;
      seat.id = `opp-${pid}`;

      const statusText = isFolded ? 'Folded' : (player.isBlind ? 'Blind' : 'Seen');
      const statusClass = isFolded ? 'folded' : (player.isBlind ? 'blind' : 'seen');

      let cardBacks = '';
      const cardCount = player.cardCount || 3;
      for (let i = 0; i < cardCount; i++) {
        cardBacks += `<div class="opp-card-back"></div>`;
      }

      seat.innerHTML = `
        <div class="opp-avatar" style="background:${player.avatar.color}; border-color:${isActive ? 'var(--gold)' : 'transparent'}">
          ${player.avatar.initials}
        </div>
        ${!player.isActive ? '<small style="color:#e74c3c;font-size:0.65rem">offline</small>' : ''}
        <div class="opp-name">${escHtml(player.name)}</div>
        <div class="opp-chips">₹${player.chips}</div>
        ${player.totalBet > 0 ? `<div class="opp-bet">Bet: ₹${player.totalBet}</div>` : ''}
        <div class="opp-cards">${cardBacks}</div>
        <div class="opp-status ${statusClass}">${statusText}</div>
        ${State.isHost && pid !== State.playerId ? `<button onclick="kickPlayer('${pid}')" style="font-size:0.6rem;background:none;border:none;color:#888;cursor:pointer">kick</button>` : ''}
      `;

      if (isFolded) seat.style.opacity = '0.5';
      area.appendChild(seat);
    }
  },

  renderJokers(state) {
    const jokerDiv = document.getElementById('joker-display');
    const jokerCards = document.getElementById('joker-cards');
    const round = state.round;
    if (round && round.jokers && round.jokers.length > 0) {
      jokerCards.textContent = round.jokers.join(', ');
      jokerDiv.style.display = 'block';
    } else {
      jokerDiv.style.display = 'none';
    }
  },

  renderMyCards() {
    const blindWrap = document.getElementById('cards-blind');
    const revealedWrap = document.getElementById('cards-revealed');

    if (State.cardsRevealed && State.myHand.length > 0) {
      blindWrap.style.display = 'none';
      revealedWrap.style.display = 'flex';
      revealedWrap.innerHTML = '';

      const jokers = State.currentRound?.jokers || [];
      for (const card of State.myHand) {
        const isRed = card.suit === '♥' || card.suit === '♦';
        const isJokerCard = jokers.includes(card.rank);
        const el = document.createElement('div');
        el.className = `card card-face ${isRed ? 'red' : ''} ${isJokerCard ? 'joker-card' : ''}`;
        el.innerHTML = `
          <div class="card-rank">${card.rank}</div>
          <div class="card-suit">${card.suit}</div>
        `;
        revealedWrap.appendChild(el);
      }
    } else {
      blindWrap.style.display = 'flex';
      revealedWrap.style.display = 'none';
    }
  },

  updateActionArea(state) {
    if (!state || !state.round) {
      document.getElementById('action-area').style.display = 'none';
      return;
    }

    const round = state.round;
    const myPlayer = state.players[State.playerId];
    const isMyTurn = round.currentTurn === State.playerId;
    const isFolded = myPlayer?.isFolded;
    const isBlind = myPlayer?.isBlind;

    if (!isMyTurn || isFolded) {
      document.getElementById('action-area').style.display = 'none';
      document.getElementById('sideshow-request').style.display = 'none';
      return;
    }

    document.getElementById('action-area').style.display = 'block';

    const currentBet = round.currentBet || 0;
    const callAmt = isBlind ? currentBet : currentBet * 2;
    document.getElementById('cur-bet-display').textContent = `₹${currentBet}`;
    document.getElementById('my-call-display').textContent = `₹${callAmt}`;

    // Show/hide blind-play button
    document.getElementById('blind-play-btn').style.display = isBlind ? 'block' : 'none';

    // Show button only with 2 players left
    const activePlayers = round.activePlayers.filter(
      pid => !state.players[pid]?.isFolded
    );
    document.getElementById('show-btn').style.display = activePlayers.length <= 2 ? 'block' : 'none';

    // Sideshow only if > 2 active, seen player, prev player is seen
    const myIdx = activePlayers.indexOf(State.playerId);
    const prevId = activePlayers[(myIdx - 1 + activePlayers.length) % activePlayers.length];
    const canSideshow = activePlayers.length > 2 && !isBlind && prevId !== State.playerId && !state.players[prevId]?.isBlind;
    document.getElementById('sideshow-btn').style.display = canSideshow ? 'block' : 'none';

    // Raise slider
    const maxChips = myPlayer?.chips || 100;
    const slider = document.getElementById('raise-slider');
    slider.min = callAmt * 2;
    slider.max = Math.min(maxChips, 10000);
    slider.value = Math.min(callAmt * 2, maxChips);
    document.getElementById('raise-amount').textContent = `₹${slider.value}`;
  },

  updateVariationBadge(variation, jokers) {
    if (!variation) return;
    document.getElementById('variation-badge').textContent = variation.name;
  },

  showRoundOver(data) {
    document.getElementById('round-winner-name').textContent = `${data.winnerName} wins!`;
    document.getElementById('round-pot').textContent = `Wins ₹${data.pot}`;

    const handDisplay = document.getElementById('winner-hand-display');
    if (data.scores && data.scores[data.winner]) {
      handDisplay.textContent = `Hand: ${data.scores[data.winner].name || ''}`;
    }

    // Showdown hands
    const showdownEl = document.getElementById('showdown-hands');
    showdownEl.innerHTML = '';
    if (data.isShowdown && data.hands) {
      for (const [pid, hand] of Object.entries(data.hands)) {
        const player = State.gameState?.players[pid];
        if (!player) continue;
        const score = data.scores?.[pid];
        const el = document.createElement('div');
        el.className = 'showdown-player';
        const cards = hand.map(c => {
          const isRed = c.suit === '♥' || c.suit === '♦';
          return `<div class="card card-face ${isRed ? 'red' : ''}" style="width:44px;height:65px;font-size:0.8rem">
            <div class="card-rank">${c.rank}</div>
            <div class="card-suit">${c.suit}</div>
          </div>`;
        }).join('');
        el.innerHTML = `
          <div class="showdown-player-name">${escHtml(player.name)}${pid === data.winner ? ' 👑' : ''}</div>
          <div class="showdown-player-cards">${cards}</div>
          <div class="showdown-player-hand">${score?.name || ''}</div>
        `;
        showdownEl.appendChild(el);
      }
    }

    // Timer
    let t = 7;
    const timerEl = document.getElementById('next-round-timer');
    timerEl.textContent = `Next round in ${t}s...`;
    const interval = setInterval(() => {
      t--;
      if (t <= 0) { clearInterval(interval); }
      else { timerEl.textContent = `Next round in ${t}s...`; }
    }, 1000);

    document.getElementById('round-overlay').style.display = 'flex';
  },

  hideOverlay() {
    document.getElementById('round-overlay').style.display = 'none';
  },

  addActionLog(message) {
    if (!message) return;
    const container = document.getElementById('action-log-inner');
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.textContent = message;
    container.insertBefore(entry, container.firstChild);
    while (container.children.length > 8) {
      container.removeChild(container.lastChild);
    }
  },

  appendChatMessage(msg) {
    const container = document.getElementById('chat-messages');
    const el = document.createElement('div');
    el.className = `chat-msg ${msg.playerId === 'system' ? 'system' : ''}`;
    el.innerHTML = msg.playerId !== 'system'
      ? `<div class="msg-author">${escHtml(msg.playerName)}</div><div class="msg-text">${escHtml(msg.message)}</div>`
      : `<div class="msg-text">${escHtml(msg.message)}</div>`;
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
  },

  toggleChat() {
    document.getElementById('chat-panel').classList.toggle('open');
  },

  showRaise() {
    const panel = document.getElementById('raise-panel');
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
  },
  hideRaise() {
    document.getElementById('raise-panel').style.display = 'none';
  },

  showSideshowRequest(requesterName) {
    document.getElementById('sideshow-requester').textContent = requesterName;
    document.getElementById('sideshow-request').style.display = 'block';
    document.getElementById('action-area').style.display = 'none';
  },
  hideSideshowRequest() {
    document.getElementById('sideshow-request').style.display = 'none';
  },

  copyLink() {
    const link = document.getElementById('lobby-link').value;
    navigator.clipboard.writeText(link).then(() => {
      this.toast('Link copied!', 'success');
    }).catch(() => {
      // Fallback
      const el = document.getElementById('lobby-link');
      el.select();
      document.execCommand('copy');
      this.toast('Link copied!', 'success');
    });
  },

  toast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  },
};

// ===== SOUND EFFECTS =====
const SFX = {
  ctx: null,
  init() {
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {}
  },
  play(type) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    const now = this.ctx.currentTime;
    switch (type) {
      case 'chip':
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.1);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now); osc.stop(now + 0.15);
        break;
      case 'deal':
        osc.frequency.setValueAtTime(600, now);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.start(now); osc.stop(now + 0.2);
        break;
      case 'win':
        [0,0.1,0.2].forEach((t, i) => {
          const o2 = this.ctx.createOscillator();
          const g2 = this.ctx.createGain();
          o2.connect(g2); g2.connect(this.ctx.destination);
          o2.frequency.value = [523, 659, 784][i];
          g2.gain.setValueAtTime(0.3, now + t);
          g2.gain.exponentialRampToValueAtTime(0.001, now + t + 0.3);
          o2.start(now + t); o2.stop(now + t + 0.3);
        });
        break;
      case 'flip':
        osc.frequency.setValueAtTime(1000, now);
        osc.frequency.exponentialRampToValueAtTime(500, now + 0.12);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.start(now); osc.stop(now + 0.12);
        break;
    }
  }
};

// ===== STORAGE =====
const Storage = {
  save() {
    try {
      sessionStorage.setItem('tp_state', JSON.stringify({
        roomId: State.roomId,
        playerId: State.playerId,
        playerName: State.playerName,
        isHost: State.isHost,
      }));
    } catch (e) {}
  },
  load() {
    try {
      const s = sessionStorage.getItem('tp_state');
      if (s) {
        const d = JSON.parse(s);
        State.roomId = d.roomId;
        State.playerId = d.playerId;
        State.playerName = d.playerName;
        State.isHost = d.isHost;
        return true;
      }
    } catch (e) {}
    return false;
  },
  clear() {
    try { sessionStorage.removeItem('tp_state'); } catch (e) {}
  }
};

// ===== UTILITIES =====
function escHtml(str) {
  const d = document.createElement('div');
  d.appendChild(document.createTextNode(String(str)));
  return d.innerHTML;
}

function kickPlayer(pid) {
  if (!State.isHost) return;
  if (!confirm('Remove this player?')) return;
  State.socket.emit('kick_player', { targetId: pid });
}

// ===== CARD RAIN ANIMATION =====
function initCardRain() {
  const container = document.getElementById('cardRain');
  const symbols = ['🂡','🂱','🃁','🃑','A♠','K♥','Q♦','J♣','10♠','9♥'];
  const count = Math.min(15, Math.floor(window.innerWidth / 60));

  for (let i = 0; i < count; i++) {
    const card = document.createElement('div');
    card.className = 'falling-card';
    card.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    card.style.left = `${Math.random() * 100}%`;
    card.style.animationDuration = `${6 + Math.random() * 8}s`;
    card.style.animationDelay = `${-Math.random() * 10}s`;
    card.style.fontSize = `${1.5 + Math.random() * 2}rem`;
    container.appendChild(card);
  }
}

// ===== CHIP PRESET LOGIC =====
function initChipPresets() {
  document.querySelectorAll('.chip-preset').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.chip-preset').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('create-chips').value = btn.dataset.val;
    });
  });
}

// ===== RAISE SLIDER =====
function initRaiseSlider() {
  const slider = document.getElementById('raise-slider');
  slider.addEventListener('input', () => {
    document.getElementById('raise-amount').textContent = `₹${slider.value}`;
  });
}

// ===== CHAT ENTER KEY =====
function initChatInput() {
  document.getElementById('chat-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') Game.sendChat();
  });
}

// ===== URL ROUTING =====
function handleRoute() {
  const path = window.location.pathname;
  const match = path.match(/\/room\/([A-Z0-9]+)/i);
  if (match) {
    const roomId = match[1].toUpperCase();
    // Pre-fill the room code and show join screen
    UI.showScreen('join');
    document.getElementById('join-code').value = roomId;

    // Check if room needs password
    fetch(`/api/room/${roomId}`)
      .then(r => r.json())
      .then(data => {
        if (data.hasPassword) {
          document.getElementById('join-password-group').style.display = 'block';
        }
        if (data.error) {
          UI.toast('Room not found', 'error');
          UI.showLanding();
        }
      })
      .catch(() => UI.showLanding());
  }
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  initSocket();
  initCardRain();
  initChipPresets();
  initRaiseSlider();
  initChatInput();
  SFX.init();

  // Load saved state
  const hasSaved = Storage.load();

  // Handle URL routing
  handleRoute();

  // If we have saved state and no URL room, try to reconnect
  if (hasSaved && State.roomId && !window.location.pathname.match(/\/room\//)) {
    // Will auto-rejoin on socket connect
  }

  // Unlock audio on first interaction
  document.addEventListener('click', () => {
    if (SFX.ctx && SFX.ctx.state === 'suspended') {
      SFX.ctx.resume();
    }
  }, { once: true });
});
