// shared/gameEngine.js - Teen Patti Game Logic Engine

const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const RANK_VALUES = { '2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':11,'Q':12,'K':13,'A':14 };

const VARIATIONS = [
  { id: 'classic', name: 'Classic Teen Patti', description: 'Standard rules, no jokers' },
  { id: 'joker', name: 'Joker', description: 'One random card is declared joker' },
  { id: 'ak47', name: 'AK47', description: 'A, K, 4, 7 are jokers' },
  { id: 'muflis', name: 'Muflis (Lowball)', description: 'Lowest hand wins' },
  { id: '999', name: '999', description: 'Closest to 9+9+9 wins' },
  { id: 'bestoffour', name: 'Best of Four', description: '4 cards dealt, best 3 count' },
];

const HAND_RANKS = {
  TRAIL: 6,
  PURE_SEQUENCE: 5,
  SEQUENCE: 4,
  COLOR: 3,
  PAIR: 2,
  HIGH_CARD: 1
};

function createDeck(variation = 'classic') {
  let deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ suit, rank, value: RANK_VALUES[rank] });
    }
  }
  if (variation === 'bestoffour') {
    // same deck, just deal 4 cards
  }
  return shuffle(deck);
}

function shuffle(deck) {
  const d = [...deck];
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

function dealCards(deck, players, variation) {
  const cardsPerPlayer = variation === 'bestoffour' ? 4 : 3;
  const hands = {};
  let idx = 0;
  for (const pid of players) {
    hands[pid] = deck.slice(idx, idx + cardsPerPlayer);
    idx += cardsPerPlayer;
  }
  return hands;
}

function getJokers(variation, deck) {
  if (variation === 'ak47') return ['A', 'K', '4', '7'];
  if (variation === 'joker') {
    const jokerCard = deck[Math.floor(Math.random() * deck.length)];
    return [jokerCard.rank];
  }
  return [];
}

function isJoker(card, jokers) {
  return jokers.includes(card.rank);
}

function replaceJokers(hand, jokers) {
  if (!jokers || jokers.length === 0) return hand;
  // Jokers become the most useful card for the hand
  return hand.map(c => isJoker(c, jokers) ? { ...c, isJoker: true } : c);
}

function evaluateHand(cards, variation = 'classic', jokers = []) {
  let hand = [...cards];

  // For best of four, pick best 3
  if (variation === 'bestoffour' && hand.length === 4) {
    const combos = getCombinations(hand, 3);
    let best = null;
    for (const combo of combos) {
      const score = scoreHand(combo, jokers);
      if (!best || compareScores(score, best) > 0) best = score;
    }
    return best;
  }

  if (variation === '999') {
    return score999(hand);
  }

  return scoreHand(hand, jokers);
}

function getCombinations(arr, k) {
  if (k === arr.length) return [arr];
  const result = [];
  function helper(start, current) {
    if (current.length === k) { result.push([...current]); return; }
    for (let i = start; i < arr.length; i++) {
      current.push(arr[i]);
      helper(i + 1, current);
      current.pop();
    }
  }
  helper(0, []);
  return result;
}

function score999(hand) {
  // Sum of digits mod 10 for each card, closest to 27 (9+9+9)
  const digitValue = (v) => v % 10;
  const total = hand.reduce((sum, c) => sum + digitValue(c.value), 0);
  return { type: '999', total, rank: HAND_RANKS.HIGH_CARD, tiebreakers: [total] };
}

function scoreHand(hand, jokers = []) {
  const withJokers = replaceJokers(hand, jokers);
  const jokerCards = withJokers.filter(c => c.isJoker);
  const realCards = withJokers.filter(c => !c.isJoker);

  // Check for trail (three of a kind)
  const vals = hand.map(c => c.value).sort((a, b) => b - a);
  const suits = hand.map(c => c.suit);
  const ranks = hand.map(c => c.rank);

  const isFlush = suits.every(s => s === suits[0]);
  const isStraight = checkStraight(vals);
  const counts = {};
  for (const r of ranks) counts[r] = (counts[r] || 0) + 1;
  const countVals = Object.values(counts).sort((a, b) => b - a);

  // With jokers: each joker can be any card
  let handRank, name, tiebreakers;

  if (jokerCards.length === 0) {
    if (countVals[0] === 3) {
      handRank = HAND_RANKS.TRAIL; name = 'Trail';
      tiebreakers = [vals[0]];
    } else if (isFlush && isStraight) {
      handRank = HAND_RANKS.PURE_SEQUENCE; name = 'Pure Sequence';
      tiebreakers = vals;
    } else if (isStraight) {
      handRank = HAND_RANKS.SEQUENCE; name = 'Sequence';
      tiebreakers = vals;
    } else if (isFlush) {
      handRank = HAND_RANKS.COLOR; name = 'Color';
      tiebreakers = vals;
    } else if (countVals[0] === 2) {
      handRank = HAND_RANKS.PAIR; name = 'Pair';
      const pairRank = parseInt(Object.entries(counts).find(([,v]) => v === 2)[1] === 2 ? Object.entries(counts).find(([,v]) => v === 2)[0] : 0);
      tiebreakers = [RANK_VALUES[Object.entries(counts).find(([,v]) => v === 2)[0]], ...vals];
    } else {
      handRank = HAND_RANKS.HIGH_CARD; name = 'High Card';
      tiebreakers = vals;
    }
  } else {
    // With jokers, best possible hand
    if (jokerCards.length >= 2 || countVals[0] >= 2) {
      handRank = HAND_RANKS.TRAIL; name = 'Trail (Joker)';
      tiebreakers = [14];
    } else if (isFlush) {
      handRank = HAND_RANKS.PURE_SEQUENCE; name = 'Pure Sequence (Joker)';
      tiebreakers = vals;
    } else {
      handRank = HAND_RANKS.SEQUENCE; name = 'Sequence (Joker)';
      tiebreakers = vals;
    }
  }

  return { rank: handRank, name, tiebreakers, cards: hand };
}

function checkStraight(vals) {
  const sorted = [...vals].sort((a, b) => b - a);
  // Special case: A-2-3
  if (sorted[0] === 14 && sorted[1] === 3 && sorted[2] === 2) return true;
  return sorted[0] - sorted[1] === 1 && sorted[1] - sorted[2] === 1;
}

function compareScores(a, b) {
  if (a.rank !== b.rank) return a.rank - b.rank;
  for (let i = 0; i < Math.max(a.tiebreakers.length, b.tiebreakers.length); i++) {
    const diff = (a.tiebreakers[i] || 0) - (b.tiebreakers[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function compareScores999(a, b) {
  // Closest to 27 wins
  const target = 27;
  const da = Math.abs(target - a.total);
  const db = Math.abs(target - b.total);
  return db - da; // smaller distance = better
}

function determineWinner(players, hands, variation, jokers) {
  let scores = {};
  for (const [pid, hand] of Object.entries(hands)) {
    if (players.includes(pid)) {
      scores[pid] = evaluateHand(hand, variation, jokers);
    }
  }

  let winner = null;
  for (const [pid, score] of Object.entries(scores)) {
    if (!winner) { winner = pid; continue; }
    const cmp = variation === '999'
      ? compareScores999(score, scores[winner])
      : compareScores(score, scores[winner]);
    if (cmp > 0) winner = pid;
  }

  return { winner, scores };
}

function pickRandomVariation() {
  return VARIATIONS[Math.floor(Math.random() * VARIATIONS.length)];
}

module.exports = {
  VARIATIONS,
  HAND_RANKS,
  SUITS,
  RANKS,
  createDeck,
  dealCards,
  getJokers,
  evaluateHand,
  determineWinner,
  pickRandomVariation,
  shuffle
};
