// server/roomManager.js - Manages all game rooms and state

const { v4: uuidv4 } = require('uuid');
const {
  createDeck,
  dealCards,
  getJokers,
  determineWinner,
  pickRandomVariation
} = require('../shared/gameEngine');

class Room {
  constructor(hostId, hostName, settings) {
    this.id = uuidv4().slice(0, 8).toUpperCase();
    this.hostId = hostId;
    this.settings = {
      buyIn: settings.buyIn || 100,
      startingChips: settings.startingChips || 1000,
      minBet: settings.minBet || 5,
      password: settings.password || null,
      maxPlayers: settings.maxPlayers || 6,
    };
    this.players = {}; // id -> { id, name, chips, socketId, isBlind, isFolded, currentBet, isActive, isHost, avatar }
    this.spectators = {};
    this.gameState = 'lobby'; // lobby | playing | showdown
    this.round = null;
    this.chat = [];
    this.roundHistory = [];
    this.createdAt = Date.now();

    // Add host
    this.addPlayer(hostId, hostName, true);
  }

  addPlayer(playerId, playerName, isHost = false) {
    this.players[playerId] = {
      id: playerId,
      name: playerName,
      chips: this.settings.startingChips,
      socketId: null,
      isBlind: true,
      isFolded: false,
      currentBet: 0,
      totalBet: 0,
      isActive: true,
      isHost,
      avatar: this.generateAvatar(playerName),
      joinedAt: Date.now(),
    };
  }

  generateAvatar(name) {
    const colors = ['#e74c3c','#e67e22','#f1c40f','#2ecc71','#1abc9c','#3498db','#9b59b6','#e91e63'];
    const color = colors[Math.abs(name.charCodeAt(0) + name.length) % colors.length];
    return { initials: name.slice(0, 2).toUpperCase(), color };
  }

  removePlayer(playerId) {
    if (this.round && this.round.activePlayers.includes(playerId)) {
      this.foldPlayer(playerId);
    }
    delete this.players[playerId];
  }

  startGame() {
    if (this.gameState !== 'lobby') return { error: 'Game already started' };
    const playerIds = Object.keys(this.players);
    if (playerIds.length < 2) return { error: 'Need at least 2 players' };

    this.gameState = 'playing';
    this.startRound();
    return { success: true };
  }

  startRound() {
    const playerIds = Object.keys(this.players).filter(pid => this.players[pid].chips > 0);
    if (playerIds.length < 2) {
      this.gameState = 'lobby';
      return;
    }

    const variation = pickRandomVariation();
    const deck = createDeck(variation.id);
    const jokers = getJokers(variation.id, deck);
    const hands = dealCards(deck, playerIds, variation.id);

    // Reset player states
    for (const pid of playerIds) {
      this.players[pid].isBlind = true;
      this.players[pid].isFolded = false;
      this.players[pid].currentBet = 0;
      this.players[pid].totalBet = 0;
    }

    // Determine dealer (rotate each round)
    const dealerIdx = this.round
      ? (playerIds.indexOf(this.round.dealerId) + 1) % playerIds.length
      : 0;

    const bootAmount = this.settings.minBet;

    // Collect boot from all players
    const pot = playerIds.length * bootAmount;
    for (const pid of playerIds) {
      this.players[pid].chips -= bootAmount;
      this.players[pid].currentBet = bootAmount;
      this.players[pid].totalBet = bootAmount;
    }

    // Current turn: player after dealer
    const turnIdx = (dealerIdx + 1) % playerIds.length;

    this.round = {
      id: uuidv4(),
      variation,
      jokers,
      hands, // private - only send to each player
      deck,
      pot,
      sidePots: [],
      dealerId: playerIds[dealerIdx],
      currentTurnIdx: turnIdx,
      currentTurn: playerIds[turnIdx],
      activePlayers: [...playerIds],
      playerOrder: [...playerIds],
      currentBet: bootAmount,
      lastRaiser: null,
      minBet: bootAmount,
      roundNum: (this.round?.roundNum || 0) + 1,
      startedAt: Date.now(),
      actions: [],
      sideshowPending: null,
    };
  }

  getActivePlayers() {
    if (!this.round) return [];
    return this.round.activePlayers.filter(pid => !this.players[pid]?.isFolded);
  }

  performAction(playerId, action, amount = 0) {
    if (!this.round) return { error: 'No active round' };
    if (this.round.currentTurn !== playerId) return { error: 'Not your turn' };

    const player = this.players[playerId];
    if (!player) return { error: 'Player not found' };

    const isBlind = player.isBlind;
    const currentBet = this.round.currentBet;
    const minCall = isBlind ? currentBet : currentBet * 2;

    let result = { action, playerId, playerName: player.name };

    switch (action) {
      case 'fold':
        player.isFolded = true;
        this.round.activePlayers = this.round.activePlayers.filter(p => p !== playerId);
        this.round.actions.push({ playerId, action: 'fold', timestamp: Date.now() });
        result.message = `${player.name} folded`;
        break;

      case 'call':
      case 'chaal': {
        const callAmount = isBlind ? currentBet : currentBet * 2;
        const pay = Math.min(callAmount, player.chips);
        player.chips -= pay;
        player.currentBet += pay;
        player.totalBet += pay;
        this.round.pot += pay;
        if (isBlind && this.round.currentBet < callAmount) this.round.currentBet = callAmount;
        player.isBlind = false;
        this.round.actions.push({ playerId, action: 'chaal', amount: pay, timestamp: Date.now() });
        result.message = `${player.name} chaal (₹${pay})`;
        result.amount = pay;
        break;
      }

      case 'raise': {
        const raiseAmt = Math.max(amount, minCall * 2);
        const pay = Math.min(raiseAmt, player.chips);
        player.chips -= pay;
        player.currentBet += pay;
        player.totalBet += pay;
        this.round.pot += pay;
        this.round.currentBet = Math.max(this.round.currentBet, pay / (isBlind ? 1 : 2));
        player.isBlind = false;
        this.round.lastRaiser = playerId;
        this.round.actions.push({ playerId, action: 'raise', amount: pay, timestamp: Date.now() });
        result.message = `${player.name} raised ₹${pay}`;
        result.amount = pay;
        break;
      }

      case 'blind': {
        // Play blind (don't look at cards)
        const blindBet = currentBet;
        const pay = Math.min(blindBet, player.chips);
        player.chips -= pay;
        player.currentBet += pay;
        player.totalBet += pay;
        this.round.pot += pay;
        this.round.actions.push({ playerId, action: 'blind', amount: pay, timestamp: Date.now() });
        result.message = `${player.name} played blind (₹${pay})`;
        result.amount = pay;
        break;
      }

      case 'seen':
        player.isBlind = false;
        this.round.actions.push({ playerId, action: 'seen', timestamp: Date.now() });
        result.message = `${player.name} looked at cards`;
        result.showCards = true;
        break;

      case 'show': {
        // Force showdown between last 2 players
        const active = this.getActivePlayers();
        if (active.length > 2) return { error: 'Can only show with 2 players left' };
        this.round.actions.push({ playerId, action: 'show', timestamp: Date.now() });
        result.message = `${player.name} called show!`;
        result.showdown = true;
        return { ...result, ...this.resolveShowdown() };
      }

      case 'sideshow': {
        // Request sideshow with previous player
        const active = this.getActivePlayers();
        const myIdx = active.indexOf(playerId);
        const prevPlayer = active[(myIdx - 1 + active.length) % active.length];
        if (prevPlayer === playerId) return { error: 'No previous player' };
        if (this.players[prevPlayer].isBlind) return { error: 'Previous player is blind' };
        this.round.sideshowPending = { requester: playerId, target: prevPlayer };
        this.round.actions.push({ playerId, action: 'sideshow_request', timestamp: Date.now() });
        result.message = `${player.name} requested sideshow`;
        result.sideshowRequest = { target: prevPlayer, targetName: this.players[prevPlayer].name };
        return result;
      }

      case 'sideshow_accept':
      case 'sideshow_reject': {
        const pending = this.round.sideshowPending;
        if (!pending || pending.target !== playerId) return { error: 'No sideshow pending for you' };
        this.round.sideshowPending = null;

        if (action === 'sideshow_reject') {
          result.message = `${player.name} rejected sideshow`;
          this.advanceTurn();
          return result;
        }

        // Compare hands privately
        const reqHand = this.round.hands[pending.requester];
        const tgtHand = this.round.hands[pending.target];
        const { winner } = determineWinner(
          [pending.requester, pending.target],
          { [pending.requester]: reqHand, [pending.target]: tgtHand },
          this.round.variation.id,
          this.round.jokers
        );
        const loser = winner === pending.requester ? pending.target : pending.requester;
        this.players[loser].isFolded = true;
        this.round.activePlayers = this.round.activePlayers.filter(p => p !== loser);
        result.message = `Sideshow: ${this.players[loser].name} must fold`;
        result.sideshowResult = { loser, loserName: this.players[loser].name };
        break;
      }

      default:
        return { error: 'Unknown action' };
    }

    // Check if only 1 player left
    const remaining = this.getActivePlayers();
    if (remaining.length === 1) {
      return { ...result, ...this.resolveWinner(remaining[0]) };
    }

    this.advanceTurn();
    result.nextTurn = this.round.currentTurn;
    result.pot = this.round.pot;
    return result;
  }

  advanceTurn() {
    if (!this.round) return;
    const active = this.getActivePlayers();
    if (active.length === 0) return;
    const curIdx = active.indexOf(this.round.currentTurn);
    const nextIdx = (curIdx + 1) % active.length;
    this.round.currentTurn = active[nextIdx];
    this.round.currentTurnIdx = nextIdx;
  }

  resolveShowdown() {
    const active = this.getActivePlayers();
    const handSubset = {};
    for (const pid of active) handSubset[pid] = this.round.hands[pid];

    const { winner, scores } = determineWinner(active, handSubset, this.round.variation.id, this.round.jokers);
    return this.resolveWinner(winner, scores, true);
  }

  resolveWinner(winnerId, scores = {}, isShowdown = false) {
    const winner = this.players[winnerId];
    winner.chips += this.round.pot;

    const result = {
      roundOver: true,
      winner: winnerId,
      winnerName: winner.name,
      pot: this.round.pot,
      isShowdown,
      scores,
      hands: isShowdown ? this.round.hands : null,
      variation: this.round.variation,
    };

    this.roundHistory.push({
      roundNum: this.round.roundNum,
      winner: winnerId,
      winnerName: winner.name,
      pot: this.round.pot,
      variation: this.round.variation.name,
    });

    // Start next round after delay
    setTimeout(() => {
      if (this.gameState === 'playing') {
        this.startRound();
      }
    }, 8000);

    return result;
  }

  getPublicState() {
    const players = {};
    for (const [pid, p] of Object.entries(this.players)) {
      players[pid] = {
        id: p.id,
        name: p.name,
        chips: p.chips,
        isBlind: p.isBlind,
        isFolded: p.isFolded,
        currentBet: p.currentBet,
        totalBet: p.totalBet,
        isActive: p.isActive,
        isHost: p.isHost,
        avatar: p.avatar,
        cardCount: this.round ? (this.round.hands[pid]?.length || 0) : 0,
      };
    }

    return {
      id: this.id,
      gameState: this.gameState,
      settings: { ...this.settings, password: !!this.settings.password },
      players,
      round: this.round ? {
        id: this.round.id,
        variation: this.round.variation,
        jokers: this.round.jokers,
        pot: this.round.pot,
        currentTurn: this.round.currentTurn,
        currentBet: this.round.currentBet,
        minBet: this.round.minBet,
        dealerId: this.round.dealerId,
        activePlayers: this.round.activePlayers,
        roundNum: this.round.roundNum,
        actions: this.round.actions.slice(-10),
        sideshowPending: this.round.sideshowPending,
      } : null,
      chat: this.chat.slice(-50),
      roundHistory: this.roundHistory.slice(-10),
    };
  }

  getPlayerHand(playerId) {
    if (!this.round || !this.round.hands[playerId]) return [];
    return this.round.hands[playerId];
  }

  addChatMessage(playerId, message) {
    const player = this.players[playerId];
    if (!player) return null;
    const msg = {
      id: uuidv4().slice(0, 8),
      playerId,
      playerName: player.name,
      message: message.slice(0, 200),
      timestamp: Date.now(),
    };
    this.chat.push(msg);
    if (this.chat.length > 100) this.chat.shift();
    return msg;
  }
}

class RoomManager {
  constructor() {
    this.rooms = {};
    this.playerRooms = {}; // socketId -> roomId
    this.cleanupInterval = setInterval(() => this.cleanup(), 60 * 60 * 1000);
  }

  createRoom(hostSocketId, hostId, hostName, settings) {
    const room = new Room(hostId, hostName, settings);
    room.players[hostId].socketId = hostSocketId;
    this.rooms[room.id] = room;
    this.playerRooms[hostSocketId] = room.id;
    return room;
  }

  joinRoom(socketId, roomId, playerId, playerName, password) {
    const room = this.rooms[roomId];
    if (!room) return { error: 'Room not found' };
    if (room.settings.password && room.settings.password !== password) {
      return { error: 'Wrong password' };
    }
    if (Object.keys(room.players).length >= room.settings.maxPlayers && !room.players[playerId]) {
      return { error: 'Room is full' };
    }

    // Reconnection
    if (room.players[playerId]) {
      room.players[playerId].socketId = socketId;
      room.players[playerId].isActive = true;
    } else {
      if (room.gameState !== 'lobby') return { error: 'Game already in progress' };
      room.addPlayer(playerId, playerName);
      room.players[playerId].socketId = socketId;
    }

    this.playerRooms[socketId] = roomId;
    return { room, playerId };
  }

  getRoom(roomId) {
    return this.rooms[roomId];
  }

  getRoomBySocket(socketId) {
    const roomId = this.playerRooms[socketId];
    return roomId ? this.rooms[roomId] : null;
  }

  getPlayerIdBySocket(socketId) {
    const room = this.getRoomBySocket(socketId);
    if (!room) return null;
    for (const [pid, p] of Object.entries(room.players)) {
      if (p.socketId === socketId) return pid;
    }
    return null;
  }

  handleDisconnect(socketId) {
    const room = this.getRoomBySocket(socketId);
    if (!room) return null;
    const playerId = this.getPlayerIdBySocket(socketId);
    if (playerId && room.players[playerId]) {
      room.players[playerId].isActive = false;
    }
    delete this.playerRooms[socketId];
    return { room, playerId };
  }

  cleanup() {
    const now = Date.now();
    for (const [id, room] of Object.entries(this.rooms)) {
      if (now - room.createdAt > 12 * 60 * 60 * 1000) {
        delete this.rooms[id];
      }
    }
  }
}

module.exports = { Room, RoomManager };
