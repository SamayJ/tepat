// server/index.js - Main server

const express = require('express');
const { createServer } = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { RoomManager } = require('./roomManager');

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
});

const roomManager = new RoomManager();

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Serve the app for all routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.get('/room/:roomId', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// REST: Get room info (for join page)
app.get('/api/room/:roomId', (req, res) => {
  const room = roomManager.getRoom(req.params.roomId.toUpperCase());
  if (!room) return res.status(404).json({ error: 'Room not found' });
  res.json({
    id: room.id,
    playerCount: Object.keys(room.players).length,
    maxPlayers: room.settings.maxPlayers,
    gameState: room.gameState,
    hasPassword: !!room.settings.password,
    buyIn: room.settings.buyIn,
    startingChips: room.settings.startingChips,
  });
});

// ======= Socket.io Events =======
io.on('connection', (socket) => {
  console.log(`Socket connected: ${socket.id}`);

  // Create a new room
  socket.on('create_room', (data, cb) => {
    try {
      const { playerName, settings } = data;
      const playerId = uuidv4();
      const room = roomManager.createRoom(socket.id, playerId, playerName || 'Host', settings || {});
      socket.join(room.id);
      socket.data.playerId = playerId;
      socket.data.roomId = room.id;

      cb({
        success: true,
        roomId: room.id,
        playerId,
        state: room.getPublicState(),
        hand: [],
      });
    } catch (e) {
      cb({ error: e.message });
    }
  });

  // Join existing room
  socket.on('join_room', (data, cb) => {
    try {
      const { roomId, playerName, playerId: existingId, password } = data;
      const pid = existingId || uuidv4();
      const result = roomManager.joinRoom(socket.id, roomId.toUpperCase(), pid, playerName || 'Player', password);

      if (result.error) return cb({ error: result.error });

      const { room } = result;
      socket.join(room.id);
      socket.data.playerId = pid;
      socket.data.roomId = room.id;

      const hand = room.getPlayerHand(pid);
      cb({
        success: true,
        roomId: room.id,
        playerId: pid,
        state: room.getPublicState(),
        hand,
      });

      // Notify others
      socket.to(room.id).emit('player_joined', {
        playerId: pid,
        playerName: playerName,
        state: room.getPublicState(),
      });
    } catch (e) {
      cb({ error: e.message });
    }
  });

  // Host starts game
  socket.on('start_game', (data, cb) => {
    try {
      const room = roomManager.getRoomBySocket(socket.id);
      const playerId = roomManager.getPlayerIdBySocket(socket.id);
      if (!room) return cb({ error: 'Not in a room' });
      if (!room.players[playerId]?.isHost) return cb({ error: 'Only host can start' });

      const result = room.startGame();
      if (result.error) return cb({ error: result.error });

      // Send each player their hand privately
      for (const [pid, player] of Object.entries(room.players)) {
        const playerSocket = getSocketByPlayerId(room, pid);
        if (playerSocket) {
          const hand = room.getPlayerHand(pid);
          playerSocket.emit('round_started', {
            state: room.getPublicState(),
            hand,
            variation: room.round.variation,
            jokers: room.round.jokers,
          });
        }
      }

      cb({ success: true });
    } catch (e) {
      cb({ error: e.message });
    }
  });

  // Player action
  socket.on('player_action', (data, cb) => {
    try {
      const room = roomManager.getRoomBySocket(socket.id);
      const playerId = roomManager.getPlayerIdBySocket(socket.id);
      if (!room || !playerId) return cb({ error: 'Not in a room' });

      const { action, amount } = data;
      const result = room.performAction(playerId, action, amount);

      if (result.error) return cb({ error: result.error });

      // Broadcast action result
      io.to(room.id).emit('action_result', {
        ...result,
        state: room.getPublicState(),
      });

      // If round is over, broadcast after delay then send new hands
      if (result.roundOver) {
        setTimeout(() => {
          if (room.gameState === 'playing' && room.round) {
            for (const [pid, player] of Object.entries(room.players)) {
              const playerSocket = getSocketByPlayerId(room, pid);
              if (playerSocket) {
                const hand = room.getPlayerHand(pid);
                playerSocket.emit('round_started', {
                  state: room.getPublicState(),
                  hand,
                  variation: room.round.variation,
                  jokers: room.round.jokers,
                });
              }
            }
          }
        }, 8000);
      }

      // Handle sideshow - notify target
      if (result.sideshowRequest) {
        const targetSocket = getSocketByPlayerId(room, result.sideshowRequest.target);
        if (targetSocket) {
          targetSocket.emit('sideshow_request', {
            requester: playerId,
            requesterName: room.players[playerId]?.name,
          });
        }
      }

      cb({ success: true, result });
    } catch (e) {
      cb({ error: e.message });
    }
  });

  // Look at cards (seen)
  socket.on('see_cards', (data, cb) => {
    try {
      const room = roomManager.getRoomBySocket(socket.id);
      const playerId = roomManager.getPlayerIdBySocket(socket.id);
      if (!room || !playerId) return cb({ error: 'Not in a room' });

      const player = room.players[playerId];
      if (!player.isBlind) return cb({ hand: room.getPlayerHand(playerId) });

      // Perform seen action
      room.performAction(playerId, 'seen');
      const hand = room.getPlayerHand(playerId);

      // Broadcast state update
      io.to(room.id).emit('state_update', { state: room.getPublicState() });

      cb({ success: true, hand });
    } catch (e) {
      cb({ error: e.message });
    }
  });

  // Chat message
  socket.on('chat_message', (data) => {
    const room = roomManager.getRoomBySocket(socket.id);
    const playerId = roomManager.getPlayerIdBySocket(socket.id);
    if (!room || !playerId) return;

    const msg = room.addChatMessage(playerId, data.message || '');
    if (msg) {
      io.to(room.id).emit('chat_message', msg);
    }
  });

  // Host ends game
  socket.on('end_game', (data, cb) => {
    try {
      const room = roomManager.getRoomBySocket(socket.id);
      const playerId = roomManager.getPlayerIdBySocket(socket.id);
      if (!room) return cb?.({ error: 'Not in a room' });
      if (!room.players[playerId]?.isHost) return cb?.({ error: 'Only host can end game' });

      room.gameState = 'lobby';
      room.round = null;
      io.to(room.id).emit('game_ended', { state: room.getPublicState() });
      cb?.({ success: true });
    } catch (e) {
      cb?.({ error: e.message });
    }
  });

  // Get current state (reconnect)
  socket.on('get_state', (data, cb) => {
    try {
      const room = roomManager.getRoomBySocket(socket.id);
      const playerId = roomManager.getPlayerIdBySocket(socket.id);
      if (!room) return cb({ error: 'Not in a room' });
      const hand = room.getPlayerHand(playerId);
      cb({ state: room.getPublicState(), hand });
    } catch (e) {
      cb({ error: e.message });
    }
  });

  // Kick player (host only)
  socket.on('kick_player', (data, cb) => {
    try {
      const room = roomManager.getRoomBySocket(socket.id);
      const playerId = roomManager.getPlayerIdBySocket(socket.id);
      if (!room || !room.players[playerId]?.isHost) return cb?.({ error: 'Not authorized' });

      const targetSocket = getSocketByPlayerId(room, data.targetId);
      if (targetSocket) {
        targetSocket.emit('kicked', { reason: 'Removed by host' });
        targetSocket.leave(room.id);
      }
      room.removePlayer(data.targetId);
      io.to(room.id).emit('state_update', { state: room.getPublicState() });
      cb?.({ success: true });
    } catch (e) {
      cb?.({ error: e.message });
    }
  });

  // Disconnect
  socket.on('disconnect', () => {
    console.log(`Socket disconnected: ${socket.id}`);
    const result = roomManager.handleDisconnect(socket.id);
    if (result?.room) {
      socket.to(result.room.id).emit('player_disconnected', {
        playerId: result.playerId,
        playerName: result.room.players[result.playerId]?.name,
        state: result.room.getPublicState(),
      });
    }
  });
});

function getSocketByPlayerId(room, playerId) {
  const player = room.players[playerId];
  if (!player?.socketId) return null;
  return io.sockets.sockets.get(player.socketId);
}

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`\n🃏 Teen Patti Server running on port ${PORT}`);
  console.log(`   http://localhost:${PORT}\n`);
});
